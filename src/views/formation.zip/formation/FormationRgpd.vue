<template lang="">
  <div class="background" style="min-height:81vh;background-image: url('../../../public/images/Formation/Formargpd.jpg');" >
    
    <div class="slider"  style="min-height:81vh;">
        <div class="intro col-8 mx-auto">
          <div class="title">
                <h3>Faites appel à des spécialistes</h3>
            </div>
            <div class="content">
                <h4>Pour votre conformité RGPD</h4>
            </div>
            <div class="action">
                <a href="#contenu">Découvrez maintenant</a>
            </div>
        </div>
    </div>
</div>
      <div class="container mt-5 mb-5" id="contenu">
        <div >
          <span class="heading-title title-color-primary h3 font-weight-bold">Formation aux bonnes pratiques de protection des données personnelles</span>
          <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
        
        <ul>A l'issue de cette formation, le participant sera en capacité de :
          <li>-COMPRENDRE l’évolution juridique de la protection des données personnelles.</li>
          <li>-ACQUÉRIR des connaissances solides relatives aux définitions et aux principes du RGPD.</li>
          <li>-APPRÉHENDER la fonction et les missions du délégué à la protection des données.</li>
          <li>-ACCROÎTRE ces compétences opérationnelles à l’aide de mises en situation.</li>
        </ul>
      </div>
      <div class="mt-5">
        <img class="mx-auto rounded mb-3" src="../../../public/images/Programme.jpg" height="70" width="70" alt="">
      <ul class="mt-1">
        <li>-Le cadre juridique du RGPD.</li>
        <li>-Les Définitions.</li>
        <li>-La CNIL - Autorité de Régulation</li>
        <li>-Les acteurs du RGPD.</li>
        <li>-Les Principes du RGPD.</li>
        <li>-Les Obligations du RGPD.</li>
        <li>-Le Droit des personnes.</li>
        <li>-Le Délégué à la Protection des Données.</li>
        <li>-Les Formalités.</li>
        <li>-Les Transferts de données.</li>
      </ul>
    </div>
    <div class="mt-5">
      <img class="mx-auto rounded my-5" src="../../../public/images/Pratique.jpg" height="70" width="70" alt="">
    <span class="bg-info  p-3 text-light">Méthodes pédagogiques</span>
  <ul class="mt-1">
    <li>-Cas pratiques (registre des traitements, applications des principes, exercice des droits, transferts des données,etc...).</li>
    <li>-Exemples et retours d’expériences.</li>
    <li>-Actualité juridique</li>
    <li>-Mise en contexte des éléments théoriques.</li>
  </ul>
  <span class="bg-info  p-3 text-light">Moyens pédagogiques</span>
  
  <ul class="mt-1">
    <li>-Support de formation.</li>
    <li>-Documentation juridique.</li>
  </ul>
  <span class="bg-info  p-3 text-light">Modalités d'évaluation</span>
  
  <ul class="mt-1">
    <li>-Contrôle continu pendant la formation.</li>
    <li>-Questionnaires à Choix Multiples (QCM) validant les différents modules.</li>
  </ul>
  </div>
  <div class="mt-5">
  <img class="mx-auto rounded my-5" src="../../../public/images/plus.jpg" height="70" width="70" alt="">
<ul class="mt-1">
<li>-Cours animés par des juristes experts en protection des données et certifiés DPO et ISO 27001.</li>
<li>-Formateurs certifiés PECB.</li>
</ul>
</div>
  
  <!-- <div>
    <div class="d-inline "><img  height="150" width="150" src="../../../public/images/certifiante.jpg" alt=""><div>hello</div></div>
    <div class="d-inline "><img  height="90" width="90" src="../../../public/images/NonCertifiante.png" alt=""></div>
  </div> -->
      <div class="mt-5">
        <span class="heading-title title-color-primary h1">Formation Délégué à la protection des données</span>
      </div>
      <div class="mt-5">
        <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
      <ul>A l'issue de cette formation, le participant sera en capacité de :
        <li>-CONNAÎTRE les missions du Data Protection Officer (DPO).</li>
        <li>-ACQUERIR les connaissances juridiques, technique et organisationnelles nécessaires à l'exercice de ces fonctions.</li>
        <li>-APPRÉHENDER les démarches et outils nécessaires au maniement des règles en matière de protection des données.</li>
        <li>-DISPOSER de l’ensemble des connaissances utiles à la réussite à l’examen de certification.</li>
      </ul>
    </div>
    <div class="mt-5">
      <img class="mx-auto rounded mb-3" src="../../../public/images/Programme.jpg" height="70" width="70" alt="">
      <span class="bg-info  p-3 text-light">Introduction au RGPD et initialisation de la conformité au RGPD </span>
    
    <ul class="mt-1">
      <li>-Introduction au RGPD.</li>
      <li>-Principes fondamentaux du RGPD.</li>
      <li>-Initialisation de la mise en oeuvre du RGPD.</li>
      <li>-Comprendre l'organisation et clarifier les objectifs de la protection des données.</li>
    </ul>

    <span class="bg-info  p-3 text-light">Planifier la mise en oeuvre du RGPD</span>
    
    <ul class="mt-1">
      <li>- Leadership et approbation du projet de conformité RGPD.</li>
      <li>-Politique de protection des données.</li>
      <li>- Définition de la structure organisationnelle de la protection des données.</li>
    </ul>
    <span class="bg-info  p-3 text-light">Déployer le RGPD </span>
    
    <ul class="mt-1">
      <li>-Étude d’impact à la vie privée (EIVP).</li>
      <li>-Contrôles, processus, politiques, procédures et gestion de la documentation.</li>
      <li>-Plan de communication.</li>
      <li>-Plan de formation et de sensibilisation.</li>
    </ul>
    <span class="bg-info  p-3 text-light">Suivi et amélioration continue de la conformité au RGPD </span>
    
    <ul class="mt-1">
      <li>-Gestion des incidents et des violations de données.</li>
      <li>-Audit interne.</li>
      <li>-Actions correctives.</li>
        </ul>
        <span class="bg-info  p-3 text-light">Passage de la certification</span>
    
    <ul class="mt-1">
      <li>-Prix et passage de la certification inclus dans le tarif .</li>
      <li>-Examen de 3h.</li>
    </ul>
  </div>
  <div class="mt-5">
    <img class="mx-auto rounded my-5" src="../../../public/images/Pratique.jpg" height="70" width="70" alt="">
  <span class="bg-info  p-3 text-light">Méthodes pédagogiques</span>
<ul class="mt-1">
  <li>-Cas pratiques (registre des traitements, applications des principes, exercice des droits, transferts des données,etc...).</li>
  <li>-Exemples et retours d’expériences.</li>
  <li>-Actualité juridique</li>
  <li>-Mise en contexte des éléments théoriques.</li>
</ul>
<span class="bg-info  p-3 text-light">Moyens pédagogiques</span>

<ul class="mt-1">
  <li>-Support de formation.</li>
  <li>-Documentation juridique.</li>
</ul>
<span class="bg-info  p-3 text-light">Modalités d'évaluation</span>

<ul class="mt-1">L’évaluation des connaissances s’effectue via:
  <li>-Contrôle continu pendant la formation.</li>
  <li>-Questionnaires à Choix Multiples (QCM) validant les différents modules.</li>
</ul>
</div>
<div class="mt-5">
  <img class="mx-auto rounded my-5" src="../../../public/images/plus.jpg" height="70" width="70" alt="">
<ul class="mt-1">
<li>-Cours animés par des juristes experts en protection des données et certifiés DPO et ISO 27001.</li>
<li>-Formateurs certifiés PECB.</li>
</ul>
</div>
      <!-- <div id="accordion" class="mt-5">
    
        <div class="card">
          <div class="card-header">
            <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
              Sensibilisation RGPD - 1h
            </a>
          </div>
          <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
  
              <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
      
      <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
      
      <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
      
      Complétez votre formation avec une vision à 360° sur le RGPD.<br>
      
      <span class="badge bg-warning mx-2">Compétences acquises :</span>
      <ul>
        <li>Les règles communes aux droits exercées par la personne concernée</li>
        <li>Les risques (contrôles et sanctions)</li>
        <li>Les obligations du responsable de traitement</li>
        <li>Les modalités de réponse</li>
      </ul>
            </div>
          </div>
        </div>
      
        <div class="card">
          <div class="card-header">
            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
              Formation RGPD - 3h
            </a>
          </div>
          <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
  
              <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
      
      <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
      
      <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
      
      Complétez votre formation avec une vision à 360° sur le RGPD.<br>
      
      <span class="badge bg-warning mx-2">Compétences acquises :</span>
      <ul>
        <li>Les règles communes aux droits exercées par la personne concernée</li>
        <li>Les risques (contrôles et sanctions)</li>
        <li>Les obligations du responsable de traitement</li>
        <li>Les modalités de réponse</li>
      </ul>
            </div>
          </div>
        </div>
      
        <div class="card">
          <div class="card-header">
            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
              Exercice des droits - 3h
            </a>
          </div>
          <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
  
          <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
  
  <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
  
  <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
  
  Complétez votre formation avec une vision à 360° sur le RGPD.<br>
  
  <span class="badge bg-warning mx-2">Compétences acquises :</span>
  <ul>
    <li>Les règles communes aux droits exercées par la personne concernée</li>
    <li>Les risques (contrôles et sanctions)</li>
    <li>Les obligations du responsable de traitement</li>
    <li>Les modalités de réponse</li>
  </ul>
            </div>
          </div>
        </div>
      
      </div> -->
    </div>
     
  </template>
  <script>
  import Intro from '@/components/Intro'
  export default {
    components:{
          Intro
      }  
  }
  </script>
  <style lang="">
      
  </style>
  