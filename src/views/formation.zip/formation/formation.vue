<template lang="">

<<<<<<< HEAD
<!-- <Intro bgUrl="background-image: url('../../../public/images/formation/FormatCyberSec.jpg);">
            <div class="title">
                <h3>Faites appel à des spécialistes</h3>
            </div>
            <div class="content">
                <h4>Pour votre conformité RGPD</h4>
            </div>
            <div class="action">
                <a href="#contenu">Découvrez maintenant</a>
            </div>
</Intro> -->

<div class="background" style="min-height:81vh;background-image: url('../../../public/images/Formation/FormatCyberSec.jpg');" >
    
    <div class="slider"  style="min-height:81vh;">
        <div class="intro col-8 mx-auto">
            <div class="content">
                <h4>Cyber sécurité</h4>
            </div>
            <div class="action">
                <a href="#contenu">Découvrez maintenant</a>
            </div>
        </div>
    </div>
</div>


    <div class="container mt-5 mb-5" id="contenu">
      <div >
        <span class="badge heading-title title-color-primary h3 font-weight-bold">Formation gestion des risques IT et Système de Management de la Sécurité de l’Information</span>
        <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
=======
  <Intro bgUrl="background-image: url('images/intro-rgpdaccomp.jpg');">
               <!-- we will get this using -->
              <div class="title">
                  <h3>Faites appel à des spécialistes</h3>
              </div>
              <div class="content">
                  <h4>Pour votre conformité RGPD</h4>
              </div>
              <div class="action">
                  <a href="#contenu">Découvrez maintenant</a>
              </div>
  </Intro>
      <div class="container mt-5 mb-5" id="contenu">
        <div >
          <span class="badge bg-primary h3 font-weight-bold">Formation gestion des risques IT et Système de Management de la Sécurité de l’Information</span>
          <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
        
        <ul>A l'issue de cette formation, le participant sera en capacité de :
          <li>-IDENTIFIER les risques associés aux TIC</li>
          <li>-ADOPTER les meilleures pratiques de gestion de la sécurité de l'information</li>
          <li>-MAÎTRISER les fondamentaux des standards du marché comme ISO 27001 ou ISO27005</li>
          <li>-METTRE EN PLACE un système de management de la sécurité</li>
        </ul>
      </div>
      <div class="mt-5">
        <img class="mx-auto rounded mb-3" src="../../../public/images/Programme.jpg" height="70" width="70" alt="">
        <span class="bg-info  p-3 text-light">Gouvernance de la sécurité de l’information</span>
>>>>>>> 50f709de27b9536a4a99f147c8cbcd15e4a83490
      
      <ul class="mt-1">
        <li>-Définition, périmètre, rôles et responsabilités.</li>
        <li>-Gestion des partenaires et fournisseurs tiers.</li>
        <li>-Gestion stratégique de la sécurité de l’information</li>
      </ul>
      <span class="bg-info  p-3 text-light">Gestion des risques et conformité</span>
      
      <ul class="mt-1">
        <li>- Introduction.</li>
        <li>-Présentation des principales normes et référentiels (ISO 27005,....).</li>
        <li>- Définition du contexte, méthodes de gestion des risques (identification, classification, analyse, réponse et plan de mitigation, revue post implémentation et risques résiduels).</li>
      </ul>
      <span class="bg-info  p-3 text-light">Introduction aux Systèmes de Management de la Sécurité de l’Information (SMSI) tel que définis par l’ISO 27001.</span>
      
      <ul class="mt-1">
        <li>-Introduction.</li>
        <li>-Démarche de mise en œuvre d'un SMSI.</li>
        <li>-Audit interne d'un SMSI</li>
        <li>-Audit externe d'un SMSI</li>
      </ul>
    </div>
    <div class="mt-5">
      <img class="mx-auto rounded my-5" src="../../../public/images/Pratique.jpg" height="70" width="70" alt="">
    <span class="bg-info  p-3 text-light">Méthodes pédagogiques</span>
  <ul class="mt-1">
    <li>-Apports théoriques.</li>
    <li>-Cas pratiques.</li>
    <li>-Exemples et retours d’expériences</li>
  </ul>
  <span class="bg-info  p-3 text-light">Moyens pédagogiques</span>
  
  <ul class="mt-1">
    <li>-Disposer d'un ordinateur portable ou d'une tablette pour la transmission des supports de formation ainsi que des différents livrables nécessaires.</li>
  </ul>
  <span class="bg-info  p-3 text-light">Modalités d'évaluation.</span>
  
  <ul class="mt-1">
    <li>-Contrôle continu pendant la formation.</li>
    <li>-Questionnaires à Choix Multiples (QCM) validant les différents modules.</li>
  </ul>
  </div>
  
  <div class="mt-5">
    <img class="mx-auto rounded my-5" src="../../../public/images/plus.jpg" height="70" width="70" alt="">
  <ul class="mt-1">
  <li>-Des cas pratiques.</li>
  <li>-Des retours d'expériences.</li>
  <li>-Cours animés par des consultants experts en cybersécurité et certifiés ISO27001</li>
  <li>-Formateurs certifiés PECB.</li>
  </ul>
  </div>
  
  <!-- <div>
    <div class="d-inline "><img  height="150" width="150" src="../../../public/images/certifiante.jpg" alt=""><div>hello</div></div>
    <div class="d-inline "><img  height="90" width="90" src="../../../public/images/NonCertifiante.png" alt=""></div>
  </div> -->
  <div class="row">
    <div class="col-sm-12 col-md-6 col-lg-6">
        <div class="activity-item">
            <div class="row">
                <a href="#" data-role="activity-box-link">
                    <div class="col-lg-12 p-0">
                        <!-- activity Image, Name & Subtitle (everyone) -->
                        <div class="activity-box-icon-container">
                            <img class="activity-box-icon" src="../../../public/images/certifiante.jpg">
                        </div>
                        <div class="activity-item-title" role="heading" aria-level="2">
                            Certifiante
                        </div>
                    </div>
                </a>
                <div class="activity-listing-subtitle">
                  <ul>
                    <li>-5 jours de formation de préparation à l’examen de certification ISO27001</li>
                    <li>-Délivrance de la certification ISO27001 par un organisme de certification accrédité</li>
                  </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-6">
      <div class="activity-item">
          <div class="row">
              <a href="#" data-role="activity-box-link">
                  <div class="col-lg-12 p-0">
                      <!-- activity Image, Name & Subtitle (everyone) -->
                      <div class="activity-box-icon-container">
                          <img class="activity-box-icon" src="../../../public/images/NonCertifiante.png">
                      </div>
                      <div class="activity-item-title" role="heading" aria-level="2">
                          Non-certifiante
                      </div>
                  </div>
              </a>
              <div class="activity-listing-subtitle"> <ul>
                <li>-5 jours de formation</li>
                <li>-Délivrance d’un certificat de réussite</li>
              </ul></div>
          </div>
      </div>
  </div>
  </div>
      <div class="mt-5">
        <span class="badge bg-primary h1">Sensibilisation à la sécurité de l’information</span>
      <h5 class="mt-1">La sensibilisation à la cybersécurité consiste à changer les habitudes de vos collaborateurs quant aux bonnes pratiques a adopté dans le cadre leurs missions. Il est important de construire et de maintenir une culture de la sécurité de l’information au sein de votre organisation.
        C’est pourquoi, SECURELABS vous propose des sessions de sensibilisation ciblées sur des thématiques bien précises et conformes à vos besoins.</h5>
      </div>
      <div class="mt-5">
        <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
      <ul>
        <li>-Diffuser à l’ensemble de vos collaborateurs des informations relatives à la sécurité des systèmes d’information.</li>
        <li>-Changer les habitudes de tout un chacun dans la sécurisation de l’information.</li>
      </ul>
    </div>
    <div class="mt-5">
      <img class="mx-auto rounded mb-3" src="../../../public/images/Programme.jpg" height="70" width="70" alt="">
      <span class="bg-info  p-3 text-light">Gouvernance de la sécurité de l’information</span>
    
    <ul class="mt-1">
      <li>-Présentation en fonction des thématiques étudiées (mot de passe, divulgation, bureau propre, bonnes pratiques de sécurité,etc..).</li>
      <li>- Audit de maturité.</li>
      <li>-Objectifs de sécurité de l’organisme.</li>
      <li>-Directives internes et Réglementations applicables.</li>
      <li>-Rôles et Responsabilités</li>
      <li>-Gestion des risques.</li>
      <li>-Recommandations.</li>
    </ul>
  </div>
      <!-- <div id="accordion" class="mt-5">
    
        <div class="card">
          <div class="card-header">
            <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
              Sensibilisation RGPD - 1h
            </a>
<<<<<<< HEAD
            <div class="activity-listing-subtitle"> <ul>
              <li>-5 jours de formation</li>
              <li>-Délivrance d’un certificat de réussite</li>
            </ul></div>
        </div>
    </div>
</div>
</div>
    <div class="mt-5">
      <span class="heading-title title-color-primary h1">Sensibilisation à la sécurité de l’information</span>
    <h5 class="mt-1">La sensibilisation à la cybersécurité consiste à changer les habitudes de vos collaborateurs quant aux bonnes pratiques a adopté dans le cadre leurs missions. Il est important de construire et de maintenir une culture de la sécurité de l’information au sein de votre organisation.
      C’est pourquoi, SECURELABS vous propose des sessions de sensibilisation ciblées sur des thématiques bien précises et conformes à vos besoins.</h5>
    </div>
    <div class="mt-5">
      <img class="mx-auto rounded my-5" src="../../../public/images/Objectif2.png" height="70" width="70" alt="">
    <ul>
      <li>-Diffuser à l’ensemble de vos collaborateurs des informations relatives à la sécurité des systèmes d’information.</li>
      <li>-Changer les habitudes de tout un chacun dans la sécurisation de l’information.</li>
    </ul>
  </div>
  <div class="mt-5">
    <img class="mx-auto rounded mb-3" src="../../../public/images/Programme.jpg" height="70" width="70" alt="">
    <span class="bg-info  p-3 text-light">Gouvernance de la sécurité de l’information</span>
=======
          </div>
          <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
>>>>>>> 50f709de27b9536a4a99f147c8cbcd15e4a83490
  
              <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
      
      <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
      
      <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
      
      Complétez votre formation avec une vision à 360° sur le RGPD.<br>
      
      <span class="badge bg-warning mx-2">Compétences acquises :</span>
      <ul>
        <li>Les règles communes aux droits exercées par la personne concernée</li>
        <li>Les risques (contrôles et sanctions)</li>
        <li>Les obligations du responsable de traitement</li>
        <li>Les modalités de réponse</li>
      </ul>
            </div>
          </div>
        </div>
      
        <div class="card">
          <div class="card-header">
            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
              Formation RGPD - 3h
            </a>
          </div>
          <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
  
              <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
      
      <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
      
      <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
      
      Complétez votre formation avec une vision à 360° sur le RGPD.<br>
      
      <span class="badge bg-warning mx-2">Compétences acquises :</span>
      <ul>
        <li>Les règles communes aux droits exercées par la personne concernée</li>
        <li>Les risques (contrôles et sanctions)</li>
        <li>Les obligations du responsable de traitement</li>
        <li>Les modalités de réponse</li>
      </ul>
            </div>
          </div>
        </div>
      
        <div class="card">
          <div class="card-header">
            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
              Exercice des droits - 3h
            </a>
          </div>
          <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
            <div class="card-body">
              <span class="badge bg-warning mx-2">Lieu:</span>Visio-conférence ou présentiel. Le déplacement de nos équipes inclut un tarif supplémentaire à la prestation de formation<br>
  
          <span class="badge bg-warning mx-2">Nb de personnes:</span>20 personnes maximum<br>
  
  <span class="badge bg-warning mx-2">Connaissances requises:</span> Avoir une bonne connaissance des principes fondamentaux du RGPD et être sensibilisé au métier et rôle du DPO.<br>
  
  <span class="badge bg-warning mx-2">Objectifs de la formation :</span>
  
  Complétez votre formation avec une vision à 360° sur le RGPD.<br>
  
  <span class="badge bg-warning mx-2">Compétences acquises :</span>
  <ul>
    <li>Les règles communes aux droits exercées par la personne concernée</li>
    <li>Les risques (contrôles et sanctions)</li>
    <li>Les obligations du responsable de traitement</li>
    <li>Les modalités de réponse</li>
  </ul>
            </div>
          </div>
        </div>
      
      </div> -->
    </div>
     
  </template>
  <script>
  import Intro from '@/components/Intro'
  export default {
    components:{
          Intro
      }
      
  }
  </script>
  <style lang="">
      
  </style>